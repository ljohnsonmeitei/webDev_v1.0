import React from 'react';
import '../styles/Footer.css';

const Footer = () => (
  <footer className="footer">
    <p>&copy; 2024 ITConsultPro. All rights reserved.</p>
    <div className="social-links">
      <a href="#">LinkedIn</a>
      <a href="#">Twitter</a>
      <a href="#">Facebook</a>
    </div>
  </footer>
);

export default Footer;
