import React from 'react';
import ServiceCard from './ServiceCard';
import './styles/Services.css';

const Services = () => (
  <section id="services" className="services">
    <h2>Our Services</h2>
    <div className="services-list">
      <ServiceCard title="Cloud Consulting" description="Leverage the power of cloud to streamline your operations." />
      <ServiceCard title="Cybersecurity" description="Protect your business with robust cybersecurity solutions." />
      <ServiceCard title="Data Analytics" description="Turn data into actionable insights with our analytics services." />
      <ServiceCard title="Software Development" description="Build custom software solutions tailored to your needs." />
    </div>
  </section>
);

export default Services;
