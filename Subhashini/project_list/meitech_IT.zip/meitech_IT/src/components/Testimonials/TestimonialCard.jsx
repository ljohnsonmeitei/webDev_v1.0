import React from 'react';
import './TestimonialCard.css';

const TestimonialCard = ({ quote, author }) => (
  <div className="testimonial-card">
    <p>"{quote}"</p>
    <h4>{author}</h4>
  </div>
);

export default TestimonialCard;
