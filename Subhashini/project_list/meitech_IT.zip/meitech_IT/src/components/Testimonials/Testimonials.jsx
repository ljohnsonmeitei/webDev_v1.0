import React from 'react';
import TestimonialCard from './TestimonialCard';
import './Testimonials.css';

const Testimonials = () => (
  <section id="testimonials" className="testimonials">
    <h2>What Our Clients Say</h2>
    <div className="testimonial-list">
      <TestimonialCard
        quote="ITConsultPro helped us migrate to the cloud seamlessly. Their expertise is unparalleled."
        author="John Doe, CEO of TechCorp"
      />
      <TestimonialCard
        quote="The cybersecurity solutions provided by ITConsultPro saved our business from a major threat."
        author="Jane Smith, Founder of InnovateNow"
      />
    </div>
  </section>
);

export default Testimonials;
