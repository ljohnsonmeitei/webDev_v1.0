import React from 'react';
import '../Styles/AboutUs.css';

const AboutUs = () => (
  <section id="about" className="about-us">
    <h2>About Us</h2>
    <p>
      At ITConsultPro, we are dedicated to providing comprehensive IT solutions to businesses of all sizes. Our team of
      seasoned experts is passionate about leveraging technology to drive innovation and efficiency.
    </p>
    <p>
      With years of experience and a proven track record, we partner with you to overcome challenges and achieve your goals.
    </p>
  </section>
);

export default AboutUs;
    