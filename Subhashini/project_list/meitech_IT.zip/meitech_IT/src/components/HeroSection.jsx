import React from 'react';
import '../styles/HeroSection.css';

const HeroSection = () => (
  <section className="hero">
    <div className="hero-content">
      <h1>Innovative IT Solutions for Your Business</h1>
      <p>Transforming businesses with cutting-edge technology and expert consultancy services.</p>
      <a href="#contact" className="btn-primary">Get Started</a>
    </div>
  </section>
);

export default HeroSection;
