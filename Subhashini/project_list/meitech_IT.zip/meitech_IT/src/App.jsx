import React from 'react';
import './App.css';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import Services from './components/Services/Services';
import AboutUs from './components/AboutUs';
import Testimonials from './components/Testimonials/Testimonials';
import ContactUs from './components/ContactUs';
import Footer from './components/Footer';

const App = () => {
  return (
    <div className="App">
      <Header />
      <HeroSection />
      <Services />
      <AboutUs />
      <Testimonials />
      <ContactUs />
      <Footer />
    </div>
  );
};

export default App;
